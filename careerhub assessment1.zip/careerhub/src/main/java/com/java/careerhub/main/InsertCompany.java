package com.java.careerhub.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.careerhub.dao.Companydaoimpl;
import com.java.careerhub.util.model.Company;

public class InsertCompany {
 public static void main(String[] args) {
	 int companyID;	
	 String companyname,location;
	 Scanner sc=new Scanner (System.in);
	 Company cmpny=new Company();
	 
	 System.out.println("Enter the companyID:");
	 cmpny.setCompanyID(sc.nextInt());	 
	  
	 System.out.println("Enter the CompanyName:");
	 cmpny.setCompanyname(sc.next());
	 
	 System.out.println("Enter the Company location:");
	 cmpny.setLocation(sc.next());
	 
	 Companydaoimpl dao=new Companydaoimpl();
	 try {
		System.out.println(dao.InsertCompany(cmpny));
	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 
	 
	 
}
 
}

package com.java.careerhub.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.careerhub.util.DBConnUtil;
import com.java.careerhub.util.DBPropertyUtil;
import com.java.careerhub.util.model.Company;



public class Companydaoimpl implements Companydao {
	Connection connection;
	PreparedStatement pst;
	
	public List<Company> ShowCompanies() throws ClassNotFoundException, SQLException 
	{
		String connStr=DBPropertyUtil.Connectionstring("db");
		connection=DBConnUtil.getConnection(connStr);
		String cmd="select * from companies"; 
//CompanyID,companyName,location
		pst=connection.prepareStatement(cmd);
		ResultSet rs=pst.executeQuery();
		List<Company> companylist=new ArrayList<Company>();
		Company  cmpny=null;
		while(rs.next())
		{ cmpny=new Company();
		cmpny.setCompanyID(rs.getInt("companyID"));
		cmpny.setCompanyname(rs.getString("companyName"));
		cmpny.setLocation(rs.getString("location"));
		
		 companylist.add(cmpny);
		}
		return companylist;
		}
	
	
//	insert Company
	public String InsertCompany(Company cmpny) throws ClassNotFoundException, SQLException
	{
		String connStr=DBPropertyUtil.Connectionstring("db");
		connection=DBConnUtil.getConnection(connStr);
		String cmd = "Insert into companies(CompanyID,companyName,location) "
				+ " values(?,?,?)";
		pst=connection.prepareStatement(cmd);
		pst.setInt(1,cmpny.getCompanyID());
		pst.setString(2,cmpny.getCompanyname());
		pst.setString(3,cmpny.getLocation());
		pst.executeUpdate();
		return "Successfully inserted Company details";



	}
}

package com.java.careerhub.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.careerhub.util.model.Company;

public interface Companydao {
	List<Company> ShowCompanies() throws ClassNotFoundException, SQLException;
	String InsertCompany(Company cmpny) throws ClassNotFoundException, SQLException;
}

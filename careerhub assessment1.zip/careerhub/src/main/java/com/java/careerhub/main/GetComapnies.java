package com.java.careerhub.main;

import java.sql.SQLException;
import java.util.List;

import com.java.careerhub.dao.Companydaoimpl;
import com.java.careerhub.util.model.Company;

public class GetComapnies {
public static void main(String[] args) {
	Companydaoimpl dao =new Companydaoimpl();
	try {
		List<Company> companies=dao.ShowCompanies();
		for (Company company : companies) {
			System.out.println(company);
		}
	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}

package com.java.careerhub.main;

import java.sql.SQLException;
import java.util.List;

import com.java.careerhub.dao.JobListingdaoimpl;
import com.java.careerhub.util.model.JobListing;

public class SalaryrangeQuery {
	public static void main(String[] args) throws ClassNotFoundException {
        
             JobListingdaoimpl dao= new JobListingdaoimpl();
            
            
            List<JobListing> searchResults;
			try {
				searchResults = JobListingdaoimpl.searchJobListings(70000.0, 100000.0);
				 System.out.println("Job Listings within Salary Range:");
		            for (JobListing jobListing : searchResults) 
		            {
		                System.out.println(jobListing);
		                }
			} catch (SQLException e) {
				e.printStackTrace();
			}
            
            
           
            
            
         
        } 
    }


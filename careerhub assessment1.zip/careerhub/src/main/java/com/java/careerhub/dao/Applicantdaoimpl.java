package com.java.careerhub.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.careerhub.util.DBConnUtil;
import com.java.careerhub.util.DBPropertyUtil;
import com.java.careerhub.util.model.Applicant;

public class Applicantdaoimpl implements Applicantdao{
	Connection connection;
	PreparedStatement pst;
	public List<Applicant> ShowApplicants() throws SQLException, ClassNotFoundException
	{
		String connStr=DBPropertyUtil.Connectionstring("db");
		connection=DBConnUtil.getConnection(connStr);
		String cmd="select * from applicants"; 
//	ApplicantID,firstname,lastname,email,phone,resumefile,city,state	
		pst=connection.prepareStatement(cmd);
		ResultSet rs=pst.executeQuery();
		List<Applicant> apcantlist=new ArrayList<Applicant>();
		Applicant  apcant=null;
		while(rs.next())
		{ apcant=new Applicant();
		apcant.setApplicantId(rs.getInt("ApplicantID"));
		apcant.setFirstname(rs.getString("firstname"));
		apcant.setLastname(rs.getString("lastname"));
		apcant.setEmail(rs.getString("email"));
		apcant.setPhone(rs.getString("phone"));
		apcant.setResume(rs.getString("resumefile"));
		apcant.setCity(rs.getString("city"));
		apcant.setState(rs.getString("state"));
		 apcantlist.add(apcant);
		}
		return apcantlist;}
	
//	inserting new applicant
	
	public String InsertNewApplicant(Applicant apcant) throws ClassNotFoundException, SQLException,IllegalArgumentException
	{
		String connStr=DBPropertyUtil.Connectionstring("db");
		connection=DBConnUtil.getConnection(connStr);
		String cmd = "Insert into applicants( ApplicantID, firstname, lastname, email, phone, resumefile, city, state) "
				+ " values(?,?,?,?,?,?,?,?)";
		pst=connection.prepareStatement(cmd);
		pst.setInt(1,apcant.getApplicantId());
		pst.setString(2,apcant.getFirstname());
		pst.setString(3,apcant.getLastname());
		
		if (!isValidEmailAddress(apcant.getEmail())) {
        throw new IllegalArgumentException("Invalid email address format.");
        }
		
		pst.setString(4,apcant.getEmail());
		pst.setString(5,apcant.getPhone());
		pst.setString(6,apcant.getResume());
		pst.setString(7,apcant.getCity());
		pst.setString(8,apcant.getState());
		pst.executeUpdate();
		return "Successfully inserted Applicant details";
	}
		
		boolean isValidEmailAddress(String email) 
		{
	              
	        return email.contains("@") && email.contains(".");
	    }

		


	}


	



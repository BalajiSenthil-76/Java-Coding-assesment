package com.java.careerhub.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.careerhub.dao.JobApplicationdaoimpl;
import com.java.careerhub.util.model.JobApplication;

public class InsertJobApplication {
public static void main(String[] args) {
	Scanner sc=new Scanner (System.in);
	
	JobApplication applications=new JobApplication();
//	ApplicationID,jobID,ApplicantID,CoverLetter
	System.out.println("Enter the ApplicationID:");
	applications.setApplicationID(sc.nextInt());
	
	System.out.println("Enter the jobID:");
	applications.setJobID(sc.nextInt());
	
	System.out.println("Enter the ApplicantID:");
	applications.setApplicantID(sc.nextInt());
	
	System.out.println("Enter Your CoverLetter:");
	applications.setCoverletter(sc.next());
	
	JobApplicationdaoimpl dao=new JobApplicationdaoimpl();
	try {
		System.out.println(dao.InsertNewApplication(applications));
	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}

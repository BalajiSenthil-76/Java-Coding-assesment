package com.java.careerhub.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.careerhub.dao.JobListingdaoimpl;
import com.java.careerhub.util.model.JobListing;

public class InsertjobListing {
public static void main(String[] args) {
	Scanner sc=new Scanner (System.in);
	JobListing jbl=new JobListing();
	System.out.println("Enter jobID:");
	jbl.setJobID(sc.nextInt());
	
	System.out.println("Enter companyID:");
	jbl.setCompanyID(sc.nextInt());
	
	System.out.println("Enter jobtitle:");
	jbl.setJobtitle(sc.next());
	
	System.out.println("Enter jobdescription:");
	jbl.setJobdescription(sc.next());
	
	System.out.println("Enter joblocation:");
	jbl.setJoblocation(sc.next());
	
	System.out.println("Enter Salary:");
	jbl.setSalary(sc.nextDouble());
	
	System.out.println("Enter jobtype:");
	jbl.setJobtype(sc.next());
	
	System.out.println("Enter posteddate:");
	jbl.setPosteddate(sc.next());
	
	JobListingdaoimpl dao=new JobListingdaoimpl();
	try {
		System.out.println(dao.InsertJobListing(jbl));
	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}

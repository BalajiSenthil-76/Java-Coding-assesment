package com.java.careerhub.main;

public class JobApplicationSubmission {

}

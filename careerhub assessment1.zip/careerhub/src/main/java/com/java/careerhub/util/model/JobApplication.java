package com.java.careerhub.util.model;

public class JobApplication {
  private int applicationID;
  private int jobID;
  private int applicantID;
  private String applicationdate;
  private String coverletter;
public int getApplicationID() {
	return applicationID;
}
public void setApplicationID(int applicationID) {
	this.applicationID = applicationID;
}
public int getJobID() {
	return jobID;
}
public void setJobID(int jobID) {
	this.jobID = jobID;
}
public int getApplicantID() {
	return applicantID;
}
public void setApplicantID(int applicantID) {
	this.applicantID = applicantID;
}
public String getApplicationdate() {
	return applicationdate;
}
public void setApplicationdate(String applicationdate) {
	this.applicationdate = applicationdate;
}
public String getCoverletter() {
	return coverletter;
}
public void setCoverletter(String coverletter) {
	this.coverletter = coverletter;
}
@Override
public String toString() {
	return "JobApplication [applicationID=" + applicationID + ", jobID=" + jobID + ", applicantID=" + applicantID
			+ ", applicationdate=" + applicationdate + ", coverletter=" + coverletter + "]";
}
public JobApplication() {
	
	// TODO Auto-generated constructor stub
}
public JobApplication(int applicationID, int jobID, int applicantID, String applicationdate, String coverletter) {
	
	this.applicationID = applicationID;
	this.jobID = jobID;
	this.applicantID = applicantID;
	this.applicationdate = applicationdate;
	this.coverletter = coverletter;
}
  
  



}

package com.java.careerhub.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.careerhub.util.DBConnUtil;
import com.java.careerhub.util.DBPropertyUtil;
import com.java.careerhub.util.model.JobListing;



public class JobListingdaoimpl implements JobListingDao{
	static Connection connection;
	static PreparedStatement pst;
	
	public List<JobListing> ShowJobList() throws SQLException, ClassNotFoundException {
		String connStr=DBPropertyUtil.Connectionstring("db");
		connection=DBConnUtil.getConnection(connStr);
		String cmd="select * from jobs";
		pst=connection.prepareStatement(cmd);
		ResultSet rs=pst.executeQuery();
		List<JobListing> jobslist=new ArrayList<JobListing>();
		JobListing  jobs=null;
		while(rs.next())
		{ jobs=new JobListing();
			jobs.setJobID(rs.getInt("jobID"));
			jobs.setCompanyID(rs.getInt("companyID"));
			jobs.setJobtitle(rs.getString("jobTitle"));
			jobs.setJobdescription(rs.getString("jobdescription"));
			jobs.setJoblocation(rs.getString("joblocation"));
			jobs.setSalary(rs.getDouble("salary"));
			jobs.setJobtype(rs.getString("jobtype"));
			jobs.setPosteddate(rs.getString("postedDate"));
		 jobslist.add(jobs);
		}
		return jobslist;
	}
	
//	insert job listings
	
	public String InsertJobListing(JobListing jbl) throws ClassNotFoundException, SQLException
	{
		String connStr=DBPropertyUtil.Connectionstring("db");
		connection=DBConnUtil.getConnection(connStr);
		String cmd = "Insert into jobs(jobID, companyID, jobTitle, jobdescription, joblocation, salary, jobtype, postedDate) "
				+ " values(?,?,?,?,?,?,?,?)";
		pst=connection.prepareStatement(cmd);
		pst.setInt(1,jbl.getJobID());
		pst.setInt(2,jbl.getCompanyID());
		pst.setString(3,jbl.getJobtitle());
		pst.setString(4,jbl.getJobdescription());
		pst.setString(5,jbl.getJoblocation());
		pst.setDouble(6,jbl.getSalary());
		pst.setString(7,jbl.getJobtype());
		pst.setString(8,jbl.getPosteddate());
		
		pst.executeUpdate();
		return "Successfully inserted JobListings";


			
	}
	
	public static List<JobListing> searchJobListings(double minSalary, double maxSalary) throws ClassNotFoundException, SQLException 
	{
		String connStr=DBPropertyUtil.Connectionstring("db");
		connection=DBConnUtil.getConnection(connStr);
		
		
		 List<JobListing> jobListings = new ArrayList<>();
		 String query = "SELECT * FROM jobs WHERE salary BETWEEN ? AND ?";
	        pst = connection.prepareStatement(query);
	            pst.setDouble(1, minSalary);
	            pst.setDouble(2, maxSalary);
	            ResultSet rs = pst.executeQuery();
	                while (rs.next()) 
	                {
	                    int jobID = rs.getInt("jobID");
	                    int companyID = rs.getInt("companyID");
	                    String jobTitle = rs.getString("jobtitle");
	                    String jobDescription = rs.getString("jobdescription");
	                    String jobLocation = rs.getString("joblocation");
	                    double salary = rs.getDouble("salary");
	                    String jobType = rs.getString("jobtype");
	                    String postedDate = rs.getString("posteddate");

	                    JobListing jobListing = new JobListing(jobID, companyID, jobTitle, jobDescription, jobLocation, salary, jobType, postedDate);
	                    jobListings.add(jobListing);
	                }
	                return jobListings;
	            }
	        }
	        
	    
	



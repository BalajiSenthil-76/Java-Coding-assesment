package com.java.careerhub.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.careerhub.dao.Applicantdaoimpl;
import com.java.careerhub.util.model.Applicant;

public class InsertApplicant {
public static void main(String[] args) {
	Scanner sc=new Scanner (System.in);
	
	Applicant appcant=new Applicant();
//	ApplicantID,firstname,lastname,email,phone,resumefile,city,state	
	System.out.println("Enter ApplicantID:");
	appcant.setApplicantId(sc.nextInt());

	System.out.println("Enter  your FirstName:");
	appcant.setFirstname(sc.next());

	System.out.println("Enter  your LastName:");
	appcant.setLastname(sc.next());

	System.out.println("Enter  your Email:");
	appcant.setEmail(sc.next());
	
	System.out.println("Enter  your Phonenumber:");
	appcant.setPhone(sc.next());
	
	System.out.println("Enter  your Resumefile :");
	appcant.setResume(sc.next());
	
	System.out.println("Enter  your City:");
	appcant.setCity(sc.next());
	
	System.out.println("Enter  your State:");
	appcant.setState(sc.next());
	
	Applicantdaoimpl dao=new Applicantdaoimpl();
	try {
		System.out.println(dao.InsertNewApplicant(appcant));
	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}

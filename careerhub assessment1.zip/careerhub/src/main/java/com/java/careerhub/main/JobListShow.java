package com.java.careerhub.main;

import java.sql.SQLException;
import java.util.List;

import com.java.careerhub.dao.JobListingDao;
import com.java.careerhub.dao.JobListingdaoimpl;
import com.java.careerhub.util.model.JobListing;



public class JobListShow {
public static void main(String[] args) {
	JobListingdaoimpl dao = new JobListingdaoimpl();
	try {
		List<JobListing> jobslist=dao.ShowJobList() ;
		for (JobListing jobListing : jobslist) {
			System.out.println(jobListing);
		}
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}

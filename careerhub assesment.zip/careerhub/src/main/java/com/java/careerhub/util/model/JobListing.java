package com.java.careerhub.util.model;

public class JobListing {
  private int jobID;
  private int companyID;
  private String jobtitle;
  private String jobdescription;
  private String joblocation;
  private double salary;
  private String jobtype;
  private String posteddate;
public int getJobID() {
	return jobID;
}
public void setJobID(int jobID) {
	this.jobID = jobID;
}
public int getCompanyID() {
	return companyID;
}
public void setCompanyID(int companyID) {
	this.companyID = companyID;
}
public String getJobtitle() {
	return jobtitle;
}
public void setJobtitle(String jobtitle) {
	this.jobtitle = jobtitle;
}
public String getJobdescription() {
	return jobdescription;
}
public void setJobdescription(String jobdescription) {
	this.jobdescription = jobdescription;
}
public String getJoblocation() {
	return joblocation;
}
public void setJoblocation(String joblocation) {
	this.joblocation = joblocation;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public String getJobtype() {
	return jobtype;
}
public void setJobtype(String jobtype) {
	this.jobtype = jobtype;
}
public String getPosteddate() {
	return posteddate;
}
public void setPosteddate(String posteddate) {
	this.posteddate = posteddate;
}


@Override
public String toString() {
	return "JobListing [jobID=" + jobID + ", companyID=" + companyID + ", jobtitle=" + jobtitle + ", jobdescription="
			+ jobdescription + ", joblocation=" + joblocation + ", salary=" + salary + ", jobtype=" + jobtype
			+ ", posteddate=" + posteddate + "]";
}


public JobListing() {

	// TODO Auto-generated constructor stub
}
public JobListing(int jobID, int companyID, String jobtitle, String jobdescription, String joblocation, double salary,
		String jobtype, String posteddate) {
	
	this.jobID = jobID;
	this.companyID = companyID;
	this.jobtitle = jobtitle;
	this.jobdescription = jobdescription;
	this.joblocation = joblocation;
	this.salary = salary;
	this.jobtype = jobtype;
	this.posteddate = posteddate;
}






  
  
  

}

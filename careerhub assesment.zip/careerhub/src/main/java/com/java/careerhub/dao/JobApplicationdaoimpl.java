package com.java.careerhub.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.java.careerhub.util.DBConnUtil;
import com.java.careerhub.util.DBPropertyUtil;
import com.java.careerhub.util.model.JobApplication;

public class JobApplicationdaoimpl implements JobApplicationdao{
	Connection connection;
	PreparedStatement pst;
	public JobApplication GetApplications(int jobID) throws ClassNotFoundException, SQLException
	{
		String connStr=DBPropertyUtil.Connectionstring("db");
		connection=DBConnUtil.getConnection(connStr);
		String cmd="select * from applications where jobID=?";
//		ApplicationID,jobID,ApplicantID,CoverLetter
		pst=connection.prepareStatement(cmd);
		pst.setInt(1,jobID);
		
		
		ResultSet rs=pst.executeQuery();
		JobApplication applications=null;
				
		if(rs.next())
		{
			applications=new JobApplication();
			applications.setApplicantID(rs.getInt("ApplicationId"));
			applications.setJobID(rs.getInt("jobID"));
			applications.setApplicantID(rs.getInt("ApplicantID"));
			applications.setApplicationdate(rs.getString("ApplicationDate"));
			applications.setCoverletter(rs.getString("CoverLetter"));
		 
		}
		return applications;
	}
//		Insert new job Application:
		
		public String InsertNewApplication(JobApplication applications) throws ClassNotFoundException, SQLException
		{
			String connStr=DBPropertyUtil.Connectionstring("db");
			connection=DBConnUtil.getConnection(connStr);
			String cmd = "Insert into jobs(ApplicationID,jobID,ApplicantID,CoverLetter) "
					+ " values(?,?,?,?)";
			pst=connection.prepareStatement(cmd);
			pst.setInt(1,applications.getApplicationID());
			pst.setInt(2,applications.getJobID());
			pst.setInt(3,applications.getApplicantID());
			pst.setString(4,applications.getCoverletter());			
			pst.executeUpdate();
			return "Successfully inserted Job Apllication";
	

		}

		


	
}

package com.java.careerhub.main;

import java.sql.SQLException;
import java.util.List;

import com.java.careerhub.dao.Applicantdaoimpl;
import com.java.careerhub.util.model.Applicant;

public class GetApplicants {
public static void main(String[] args) {
	Applicantdaoimpl dao=new Applicantdaoimpl();
	try {
		List<Applicant> apcantlist=dao.ShowApplicants();
		for (Applicant applicant : apcantlist) {
			System.out.println(applicant);
		}
	} catch (ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}

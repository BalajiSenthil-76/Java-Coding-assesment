package com.java.careerhub.dao;

import java.sql.SQLException;

import com.java.careerhub.util.model.JobApplication;

public interface JobApplicationdao {
	JobApplication GetApplications(int jobID) throws ClassNotFoundException, SQLException;
	String InsertNewApplication(JobApplication applications) throws ClassNotFoundException, SQLException;}

package com.java.careerhub.util.model;

public class Company {
     private int companyID;
     private String companyname;
     private String location;
	public int getCompanyID() {
		return companyID;
	}
	public void setCompanyID(int companyID) {
		this.companyID = companyID;
	}
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	
	@Override
	public String toString() {
		return "Company [companyID=" + companyID + ", companyname=" + companyname + ", location=" + location + "]";
	}
	
	public Company() {
		
		// TODO Auto-generated constructor stub
	}
	public Company(int companyID, String companyname, String location) {
		
		this.companyID = companyID;
		this.companyname = companyname;
		this.location = location;
	}
	
	
	
	
     
     
     
}

package com.java.careerhub.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.careerhub.util.model.Applicant;

public interface Applicantdao {
	List<Applicant> ShowApplicants() throws SQLException, ClassNotFoundException;

	String InsertNewApplicant(Applicant apcant) throws ClassNotFoundException, SQLException,IllegalArgumentException;
	}

package com.java.careerhub.util.model;

public class Applicant {
  private int applicantId;
  private String firstname;
  private String lastname;
  private String email;
  private String phone;
  private String resume;
  private String city;
  private String state;
public int getApplicantId() {
	return applicantId;
}
public void setApplicantId(int applicantId) {
	this.applicantId = applicantId;
}
public String getFirstname() {
	return firstname;
}
public void setFirstname(String firstname) {
	this.firstname = firstname;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getResume() {
	return resume;
}
public void setResume(String resume) {
	this.resume = resume;
}

public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}

public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
@Override
public String toString() {
	return "Applicant [applicantId=" + applicantId + ", firstname=" + firstname + ", lastname=" + lastname + ", email="
			+ email + ", phone=" + phone + ", resume=" + resume + ",city=" + city +",state=" + state +"]";
}
public Applicant() {
	
	// TODO Auto-generated constructor stub
}
public Applicant(int applicantId, String firstname, String lastname, String email, String phone, String resume,String city,String state) {
	
	this.applicantId = applicantId;
	this.firstname = firstname;
	this.lastname = lastname;
	this.email = email;
	this.phone = phone;
	this.resume = resume;
	this.city = city;
	this.state = state;
}
  

  


  }

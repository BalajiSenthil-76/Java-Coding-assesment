package com.java.careerhub.util;

import java.util.ResourceBundle;

public class DBPropertyUtil {
	public static String Connectionstring(String propertyFile)
	{
	ResourceBundle rb=ResourceBundle.getBundle(propertyFile);
	return rb.getString("url");
	}
}

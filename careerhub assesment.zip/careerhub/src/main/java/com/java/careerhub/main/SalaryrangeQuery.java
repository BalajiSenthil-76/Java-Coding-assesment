package com.java.careerhub.main;

public class SalaryrangeQuery {
	public static void main(String[] args) {
        try {
             jobListingdaoimpl= new JobListingdaoimpl();
            
            
            List<JobListing> searchResults = J0blIstingdaoimpl.searchJobListings(70000.0, 100000.0);
            
            
            System.out.println("Job Listings within Salary Range:");
            for (JobListing jobListing : searchResults) {
                System.out.println(jobListing);
            }
            
         
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}

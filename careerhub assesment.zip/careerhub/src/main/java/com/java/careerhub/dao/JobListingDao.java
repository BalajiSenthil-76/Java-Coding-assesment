package com.java.careerhub.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.careerhub.util.model.JobListing;

public interface JobListingDao {
	
		public List<JobListing> ShowJobList() throws SQLException, ClassNotFoundException;

		
	

}

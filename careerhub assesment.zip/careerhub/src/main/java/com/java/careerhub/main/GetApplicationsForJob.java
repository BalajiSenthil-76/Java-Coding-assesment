package com.java.careerhub.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.careerhub.dao.JobApplicationdao;
import com.java.careerhub.dao.JobApplicationdaoimpl;
import com.java.careerhub.util.model.JobApplication;

public class GetApplicationsForJob {
public static void main(String[] args) {
	int jobID;
	Scanner sc=new Scanner (System.in);
	System.out.println("Enter the JobID values between 201 to 215");
	jobID=sc.nextInt();
	
	JobApplicationdaoimpl dao=new JobApplicationdaoimpl();
	
	try {
		JobApplication applications=dao.GetApplications(jobID);
		if(applications!=null)
			System.out.println(applications);
		else
			System.out.println("no one is applied for this job");
	} 
	catch 
	(ClassNotFoundException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
	

}
